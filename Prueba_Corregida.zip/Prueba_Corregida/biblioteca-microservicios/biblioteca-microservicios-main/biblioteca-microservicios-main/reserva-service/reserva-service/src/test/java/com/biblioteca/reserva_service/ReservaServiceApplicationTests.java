package com.biblioteca.reserva_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
